import { useState } from 'react';

interface InstructionsProps {
  studentName: string;
  onStartExam: () => void;
}

export function Instructions({ studentName, onStartExam }: InstructionsProps) {
  const [agreed, setAgreed] = useState(false);
  
  const handleStart = () => {
    if (agreed) {
      onStartExam();
    }
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-indigo-600 via-purple-600 to-blue-600 overflow-hidden">
      <div className="h-full w-full flex items-center justify-center p-0">
        <div className="bg-white w-full h-full md:max-w-6xl md:max-h-[95vh] md:rounded-2xl md:shadow-2xl md:m-4 overflow-hidden flex flex-col">
          {/* Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-6 sm:px-10 flex-shrink-0">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white">Mock Test Examination</h1>
                <p className="text-indigo-100 mt-1 sm:mt-2 text-sm sm:text-base">Welcome, {studentName}</p>
              </div>
              <div className="hidden sm:block text-right">
                <p className="text-indigo-100 text-xs">Mobile</p>
                <p className="font-semibold text-white">{studentName}</p>
              </div>
            </div>
          </div>

          {/* Instructions Content - Scrollable */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-gradient-to-b from-gray-50 to-white">
            <div className="max-w-5xl mx-auto">
              <div className="mb-6">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-3 flex items-center gap-3">
                  <span className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center text-white text-lg shadow-lg">📋</span>
                  Examination Instructions
                </h2>
                <div className="w-20 h-1 bg-gradient-to-r from-indigo-600 to-purple-600 rounded"></div>
              </div>

              <div className="space-y-4">
              <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-lg">
                <h3 className="font-semibold text-blue-900 mb-4">General Instructions:</h3>
                <div className="space-y-3 text-blue-800">
                  <p>The clock will be set at the server. The countdown timer at the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You need not terminate the examination or submit your paper.</p>
                </div>
              </div>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
                <h3 className="font-semibold text-yellow-900 mb-4">The Question Palette displayed on the right side of screen will show the status of each question using one of the following symbols:</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-yellow-800">
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-white border-2 border-gray-300 rounded mr-3"></div>
                    <span>You have not visited the question yet.</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-red-500 rounded mr-3"></div>
                    <span>You have not answered the question.</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-green-500 rounded mr-3"></div>
                    <span>You have answered the question.</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-purple-500 rounded mr-3"></div>
                    <span>You have NOT answered the question, but have marked the question for review.</span>
                  </div>
                  <div className="flex items-center sm:col-span-2">
                    <div className="w-6 h-6 bg-orange-500 rounded mr-3"></div>
                    <span>You have answered the question, but marked it for review.</span>
                  </div>
                </div>
                <p className="mt-4 text-yellow-800 text-sm italic">
                  The Mark For Review status for a question simply indicates that you would like to look at that question again. If a question is answered, but marked for review, then the answer will be considered for evaluation unless the status is modified by the candidate.
                </p>
              </div>

              <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded-r-lg">
                <h3 className="font-semibold text-green-900 mb-4">Navigating to a Question :</h3>
                <p className="text-green-800 mb-3">To answer a question, do the following:</p>
                <ul className="space-y-2 text-green-800 ml-4">
                  <li className="list-disc">Click on the question number in the Question Palette at the right of your screen to go to that numbered question directly. Note that using this option does NOT save your answer to the current question.</li>
                  <li className="list-disc">Click on Save & Next to save your answer for the current question and then go to the next question.</li>
                  <li className="list-disc">Click on Mark for Review & Next to save your answer for the current question and also mark it for review , and then go to the next question.</li>
                </ul>
                <p className="mt-3 text-green-800 text-sm">
                  <span className="font-semibold">Note:</span> that your answer for the current question will not be saved, if you navigate to another question directly by clicking on a question number without saving the answer to the previous question.
                </p>
              </div>

              <div className="bg-purple-50 border-l-4 border-purple-400 p-4 rounded-r-lg">
                <h3 className="font-semibold text-purple-900 mb-4">Answering a Question :</h3>
                
                <div className="mb-4">
                  <h4 className="font-semibold text-purple-900 mb-2">Procedure for answering a multiple choice (MCQ) type question:</h4>
                  <ul className="space-y-2 text-purple-800 ml-4">
                    <li className="list-disc">Choose one answer from the 4 options (A,B,C,D) given below the question, click on the bubble placed before the chosen option.</li>
                    <li className="list-disc">To deselect your chosen answer, click on the bubble of the chosen option again or click on the Clear Response button</li>
                    <li className="list-disc">To change your chosen answer, click on the bubble of another option.</li>
                    <li className="list-disc">To save your answer, you MUST click on the Save & Next</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-purple-900 mb-2">Procedure for answering a numerical answer type question :</h4>
                  <ul className="space-y-2 text-purple-800 ml-4">
                    <li className="list-disc">To enter a number as your answer, use the virtual numerical keypad.</li>
                    <li className="list-disc">A fraction (e.g. -0.3 or -.3) can be entered as an answer with or without "0" before the decimal point. As many as four decimal points, e.g. 12.5435 or 0.003 or -932.6711 or 12.82 can be entered.</li>
                    <li className="list-disc">To clear your answer, click on the Clear Response button</li>
                    <li className="list-disc">To save your answer, you MUST click on the Save & Next</li>
                  </ul>
                </div>

                <div className="mt-4 space-y-2 text-purple-800">
                  <p>To mark a question for review, click on the Mark for Review & Next button. If an answer is selected (for MCQ/MCAQ) entered (for numerical answer type) for a question that is Marked for Review , that answer will be considered in the evaluation unless the status is modified by the candidate.</p>
                  
                  <p>To change your answer to a question that has already been answered, first select that question for answering and then follow the procedure for answering that type of question.</p>
                  
                  <p className="font-semibold">Note that ONLY Questions for which answers are saved or marked for review after answering will be considered for evaluation.</p>
                </div>
              </div>

              <div className="bg-indigo-50 border-l-4 border-indigo-400 p-4 rounded-r-lg">
                <h3 className="font-semibold text-indigo-900 mb-3">Additional Navigation Features:</h3>
                <ul className="space-y-2 text-indigo-800 ml-4">
                  <li className="list-disc">Sections in this question paper are displayed on the top bar of the screen. Questions in a Section can be viewed by clicking on the name of that Section. The Section you are currently viewing will be highlighted.</li>
                  <li className="list-disc">After clicking the Save & Next button for the last question in a Section, you will automatically be taken to the first question of the next Section in sequence.</li>
                  <li className="list-disc">You can move the mouse cursor over the name of a Section to view the answering status for that Section.</li>
                </ul>
              </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-xl border-2 border-blue-200 mb-4">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreed}
                      onChange={(e) => setAgreed(e.target.checked)}
                      className="w-5 h-5 mt-0.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-gray-700 text-sm leading-relaxed">
                      I have read and understood all the instructions given above. I agree to follow all the rules and regulations of the examination.
                    </span>
                  </label>
                </div>
                
                <button
                  onClick={handleStart}
                  disabled={!agreed}
                  className={`w-full font-bold py-4 px-8 rounded-xl transform transition-all duration-200 shadow-xl text-lg ${
                    agreed
                      ? 'bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 text-white hover:from-indigo-700 hover:via-purple-700 hover:to-blue-700 hover:scale-105 cursor-pointer'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  🚀 Start Exam
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}