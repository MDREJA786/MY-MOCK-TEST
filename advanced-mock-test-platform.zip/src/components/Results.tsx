import { useState, useEffect } from 'react';

interface ResultsProps {
  studentName: string;
  studentMobile: string;
  answers: Record<number, number>;
  markedForReview: Set<number>;
  timeTaken: number;
  questions: Array<{
    id: number;
    question: string;
    options: string[];
    correctAnswer: number;
  }>;
  onRestart: () => void;
}

export function Results({ 
  studentName, 
  studentMobile, 
  answers, 
  timeTaken, 
  questions,
  onRestart 
}: ResultsProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [showReview, setShowReview] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showSolution, setShowSolution] = useState(false);
  const [confetti, setConfetti] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
      // Show confetti for high scores
      const correctCount = questions.filter(q => answers[q.id] === q.correctAnswer).length;
      const percentage = (correctCount / questions.length) * 100;
      if (percentage >= 70) {
        setConfetti(true);
        setTimeout(() => setConfetti(false), 5000);
      }
    }, 1500);
    
    return () => clearTimeout(timer);
  }, [answers, questions]);

  // Calculate results
  let correctAnswers = 0;
  let wrongAnswers = 0;
  let unanswered = 0;
  
  questions.forEach((q) => {
    if (answers[q.id] === undefined) {
      unanswered++;
    } else if (answers[q.id] === q.correctAnswer) {
      correctAnswers++;
    } else {
      wrongAnswers++;
    }
  });
  
  const totalQuestions = questions.length;
  const attempted = correctAnswers + wrongAnswers;
  const accuracy = attempted > 0 ? Math.round((correctAnswers / attempted) * 100) : 0;
  const percentage = Math.round((correctAnswers / totalQuestions) * 100);
  const grade = percentage >= 80 ? 'A+' : percentage >= 70 ? 'A' : percentage >= 60 ? 'B' : percentage >= 50 ? 'C' : 'F';
  const rank = percentage >= 90 ? 'Excellent' : percentage >= 75 ? 'Very Good' : percentage >= 60 ? 'Good' : percentage >= 50 ? 'Average' : 'Needs Improvement';
  const motivationalMessage = percentage >= 80 ? ' Excellent Performance!' : percentage >= 60 ? '👍 Good Job! Keep Practicing!' : '📚 Needs More Practice!';

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const getMotivationalColor = () => {
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-blue-600';
    return 'text-orange-600';
  };

  // Confetti Component
  const Confetti = () => (
    <div className="fixed inset-0 pointer-events-none z-50">
      {[...Array(50)].map((_, i) => (
        <div
          key={i}
          className="absolute animate-bounce"
          style={{
            left: `${Math.random() * 100}%`,
            top: '-20px',
            animationDelay: `${Math.random() * 3}s`,
            animationDuration: `${2 + Math.random() * 3}s`,
          }}
        >
          <div
            className="w-3 h-3 rounded-full"
            style={{
              backgroundColor: ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'][Math.floor(Math.random() * 5)],
              transform: `rotate(${Math.random() * 360}deg)`,
            }}
          />
        </div>
      ))}
    </div>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-blue-100 mb-4 animate-pulse">
            <svg className="animate-spin h-10 w-10 text-blue-600" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Processing Results</h2>
          <p className="text-gray-600">Evaluating your answer sheet...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative">
      {confetti && <Confetti />}
      
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl shadow-xl overflow-hidden mb-6">
          <div className="px-6 py-8 sm:px-10">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">📊 Test Results</h1>
                <p className="text-blue-100 text-lg">{studentName}</p>
                <p className="text-blue-200 text-sm">Mobile: {studentMobile}</p>
              </div>
              <div className="flex flex-wrap gap-4">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-3 text-center">
                  <div className="text-white text-xs font-medium">Test Name</div>
                  <div className="text-white font-bold">Mock Test 2025</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-3 text-center">
                  <div className="text-white text-xs font-medium">Date & Time</div>
                  <div className="text-white font-bold">{new Date().toLocaleDateString()}</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-3 text-center">
                  <div className="text-white text-xs font-medium">Time Taken</div>
                  <div className="text-white font-bold">{formatTime(timeTaken)}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Score Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow-lg p-5 transform hover:scale-105 transition-all duration-300 border-l-4 border-blue-500">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600 text-sm font-medium">Total Questions</div>
              <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div className="text-3xl font-bold text-gray-900">{totalQuestions}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-5 transform hover:scale-105 transition-all duration-300 border-l-4 border-blue-400">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600 text-sm font-medium">Attempted</div>
              <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            </div>
            <div className="text-3xl font-bold text-blue-600">{attempted}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-5 transform hover:scale-105 transition-all duration-300 border-l-4 border-green-500">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600 text-sm font-medium">Correct</div>
              <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="text-3xl font-bold text-green-600">{correctAnswers}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-5 transform hover:scale-105 transition-all duration-300 border-l-4 border-red-500">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600 text-sm font-medium">Wrong</div>
              <svg className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="text-3xl font-bold text-red-600">{wrongAnswers}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-5 transform hover:scale-105 transition-all duration-300 border-l-4 border-gray-400">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600 text-sm font-medium">Unattempted</div>
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="text-3xl font-bold text-gray-600">{unanswered}</div>
          </div>
        </div>

        {/* Main Performance Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Score Card */}
          <div className="bg-white rounded-xl shadow-xl p-6 lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Performance Summary</h2>
              <span className={`text-4xl font-bold ${getMotivationalColor()}`}>{grade}</span>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-3xl font-bold text-blue-600 mb-1">{percentage}%</div>
                <div className="text-sm text-gray-600">Overall Score</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-3xl font-bold text-green-600 mb-1">{accuracy}%</div>
                <div className="text-sm text-gray-600">Accuracy</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-3xl font-bold text-purple-600 mb-1">{correctAnswers}/{totalQuestions}</div>
                <div className="text-sm text-gray-600">Score</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-lg font-bold text-orange-600 mb-1">{rank}</div>
                <div className="text-sm text-gray-600">Rank</div>
              </div>
            </div>

            {/* Progress Bars */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Accuracy Rate</span>
                  <span className="text-sm font-medium text-gray-900">{accuracy}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div className="bg-gradient-to-r from-green-500 to-green-600 h-4 rounded-full transition-all duration-1000" style={{ width: `${accuracy}%` }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Attempt Rate</span>
                  <span className="text-sm font-medium text-gray-900">{Math.round((attempted / totalQuestions) * 100)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 h-4 rounded-full transition-all duration-1000" style={{ width: `${(attempted / totalQuestions) * 100}%` }}></div>
                </div>
              </div>
            </div>

            <div className={`mt-6 p-4 rounded-lg ${percentage >= 80 ? 'bg-green-100' : percentage >= 60 ? 'bg-blue-100' : 'bg-orange-100'}`}>
              <p className={`text-lg font-semibold ${getMotivationalColor()}`}>{motivationalMessage}</p>
            </div>
          </div>

          {/* Circular Progress */}
          <div className="bg-white rounded-xl shadow-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">Score Breakdown</h3>
            
            <div className="relative w-48 h-48 mx-auto mb-6">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="10"
                  strokeDasharray={`${(correctAnswers / totalQuestions) * 283} 283`}
                  strokeLinecap="round"
                  transform="rotate(-90 50 50)"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="10"
                  strokeDasharray={`${(wrongAnswers / totalQuestions) * 283} 283`}
                  strokeDashoffset={-(correctAnswers / totalQuestions) * 283}
                  strokeLinecap="round"
                  transform="rotate(-90 50 50)"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl font-bold text-gray-900">{percentage}%</div>
                  <div className="text-sm text-gray-600">Total Score</div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-500"></div>
                  <span className="text-sm text-gray-600">Correct</span>
                </div>
                <span className="font-bold text-green-600">{correctAnswers}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-500"></div>
                  <span className="text-sm text-gray-600">Wrong</span>
                </div>
                <span className="font-bold text-red-600">{wrongAnswers}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-gray-400"></div>
                  <span className="text-sm text-gray-600">Unattempted</span>
                </div>
                <span className="font-bold text-gray-600">{unanswered}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="bg-white rounded-xl shadow-xl p-6 mb-6">
          <div className="flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => setShowReview(true)}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-blue-800 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              Review Questions
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-700 text-white font-semibold rounded-lg hover:from-purple-700 hover:to-purple-800 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
              </svg>
              Download PDF
            </button>
            <button
              onClick={onRestart}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white font-semibold rounded-lg hover:from-green-700 hover:to-green-800 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Retake Test
            </button>
            <button
              onClick={() => {
                const text = `I scored ${percentage}% in Mock Test 2025! Grade: ${grade}. Can you beat my score?`;
                navigator.share ? navigator.share({ title: 'My Test Result', text }) : alert('Share feature not supported');
              }}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-pink-600 to-pink-700 text-white font-semibold rounded-lg hover:from-pink-700 hover:to-pink-800 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
              Share Result
            </button>
          </div>
        </div>

        {/* Question Review Modal */}
        {showReview && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4 flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">Question Review</h2>
                <button
                  onClick={() => {
                    setShowReview(false);
                    setCurrentQuestion(0);
                    setShowSolution(false);
                  }}
                  className="text-white hover:bg-white/20 rounded-full p-2 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="flex flex-1 overflow-hidden">
                {/* Question Grid Sidebar */}
                <div className="w-64 bg-gray-50 border-r p-4 overflow-y-auto">
                  <h3 className="font-bold text-gray-900 mb-4">Question Palette</h3>
                  <div className="grid grid-cols-5 gap-2">
                    {questions.map((q, index) => {
                      const userAnswer = answers[q.id];
                      const isCorrect = userAnswer === q.correctAnswer;
                      const isUnanswered = userAnswer === undefined;
                      
                      return (
                        <button
                          key={q.id}
                          onClick={() => {
                            setCurrentQuestion(index);
                            setShowSolution(false);
                          }}
                          className={`w-10 h-10 rounded-lg font-medium text-sm transition-all ${
                            currentQuestion === index
                              ? 'ring-2 ring-blue-500 ring-offset-2'
                              : ''
                          } ${
                            isUnanswered
                              ? 'bg-gray-200 text-gray-700'
                              : isCorrect
                              ? 'bg-green-500 text-white'
                              : 'bg-red-500 text-white'
                          }`}
                        >
                          {index + 1}
                        </button>
                      );
                    })}
                  </div>
                  <div className="mt-6 space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded bg-green-500"></div>
                      <span>Correct</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded bg-red-500"></div>
                      <span>Wrong</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded bg-gray-200"></div>
                      <span>Unanswered</span>
                    </div>
                  </div>
                </div>

                {/* Main Question Area */}
                <div className="flex-1 overflow-y-auto p-6">
                  <div className="max-w-3xl mx-auto">
                    {/* Question Info */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-4">
                        <span className="bg-blue-100 text-blue-700 px-4 py-2 rounded-lg font-semibold">
                          Question {currentQuestion + 1} of {totalQuestions}
                        </span>
                        <span className="text-gray-600">
                          {answers[questions[currentQuestion].id] !== undefined ? 'Attempted' : 'Not Attempted'}
                        </span>
                      </div>
                      <button
                        onClick={() => setShowSolution(!showSolution)}
                        className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                          showSolution
                            ? 'bg-purple-100 text-purple-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {showSolution ? 'Hide Solution' : 'Show Solution'}
                      </button>
                    </div>

                    {/* Question */}
                    <div className="bg-white border rounded-xl p-6 mb-6 shadow-sm">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        {questions[currentQuestion].question}
                      </h3>
                      <div className="space-y-3">
                        {questions[currentQuestion].options.map((option, optIndex) => {
                          const userAnswer = answers[questions[currentQuestion].id];
                          const isUserAnswer = userAnswer === optIndex;
                          const isCorrectAnswer = questions[currentQuestion].correctAnswer === optIndex;
                          
                          return (
                            <div
                              key={optIndex}
                              className={`p-4 rounded-lg border-2 transition-all ${
                                isCorrectAnswer
                                  ? 'border-green-500 bg-green-50'
                                  : isUserAnswer
                                  ? 'border-red-500 bg-red-50'
                                  : 'border-gray-200 bg-gray-50'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span className="font-bold text-gray-700">{String.fromCharCode(65 + optIndex)}.</span>
                                <span className={`flex-1 ${
                                  isCorrectAnswer ? 'text-green-700 font-medium' :
                                  isUserAnswer ? 'text-red-700' : 'text-gray-700'
                                }`}>
                                  {option}
                                </span>
                                {isCorrectAnswer && (
                                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                  </svg>
                                )}
                                {isUserAnswer && !isCorrectAnswer && (
                                  <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                  </svg>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Solution */}
                    {showSolution && (
                      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <h4 className="font-bold text-blue-900 mb-3 flex items-center gap-2">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Solution & Explanation
                        </h4>
                        <p className="text-blue-800">
                          <strong>Correct Answer:</strong> {String.fromCharCode(65 + questions[currentQuestion].correctAnswer)}. {questions[currentQuestion].options[questions[currentQuestion].correctAnswer]}
                        </p>
                        <p className="text-blue-700 mt-3">
                          This is the correct answer based on the standard reference. Make sure to review this concept thoroughly.
                        </p>
                      </div>
                    )}

                    {/* Navigation */}
                    <div className="flex items-center justify-between mt-6">
                      <button
                        onClick={() => {
                          if (currentQuestion > 0) {
                            setCurrentQuestion(currentQuestion - 1);
                            setShowSolution(false);
                          }
                        }}
                        disabled={currentQuestion === 0}
                        className="px-6 py-3 bg-gray-100 text-gray-700 font-semibold rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        ← Previous
                      </button>
                      <button
                        onClick={() => {
                          if (currentQuestion < totalQuestions - 1) {
                            setCurrentQuestion(currentQuestion + 1);
                            setShowSolution(false);
                          }
                        }}
                        disabled={currentQuestion === totalQuestions - 1}
                        className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        Next →
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
