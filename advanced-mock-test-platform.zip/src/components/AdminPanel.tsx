import { useState } from 'react';

interface StudentData {
  id: string;
  name: string;
  mobile: string;
  answers: Record<number, number>;
  markedForReview: Set<number>;
  timeTaken: number;
  timestamp: Date;
  score: number;
  totalQuestions: number;
}

interface AdminPanelProps {
  students: StudentData[];
  onClearData: () => void;
}

export function AdminPanel({ students, onClearData }: AdminPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'score' | 'timestamp'>('timestamp');

  const sampleQuestions = [
    { id: 1, question: "বাংলাদেশের স্বাধীনতা দিবস কবে?", options: ["২৬ মার্চ", "১৬ ডিসেম্বর", "২১ ফেব্রুয়ারি", "১৪ ডিসেম্বর"], correctAnswer: 0 },
    { id: 2, question: "বাংলাদেশের জাতীয় ফল কোনটি?", options: ["আম", "কাঁঠাল", "ফুল", "পেয়ারা"], correctAnswer: 1 },
    { id: 3, question: "বাংলাদেশের জাতীয় পাখির নাম কী?", options: ["দোয়েল", "কোয়েল", "ময়না", "শ্যামা"], correctAnswer: 0 },
  ];

  const getStudentDetails = (student: StudentData) => {
    let correctAnswers = 0;
    sampleQuestions.forEach(q => {
      if (student.answers[q.id] === q.correctAnswer) {
        correctAnswers++;
      }
    });
    
    const percentage = Math.round((correctAnswers / sampleQuestions.length) * 100);
    const grade = percentage >= 80 ? 'A+' : percentage >= 70 ? 'A' : percentage >= 60 ? 'B' : percentage >= 50 ? 'C' : 'F';
    
    return { correctAnswers, percentage, grade };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-8 sm:px-10">
            <h1 className="text-3xl font-bold text-white">শিক্ষক প্যানেল</h1>
            <p className="text-blue-100 mt-2">সমস্ত ছাত্রের পরীক্ষা ফলাফল</p>
          </div>

          <div className="p-6 sm:p-10">
            {/* Stats Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="text-blue-600 text-2xl font-bold">{students.length}</div>
                <div className="text-blue-700 text-sm font-medium">মোট ছাত্র</div>
              </div>
              <div className="bg-green-50 rounded-lg p-4">
                <div className="text-green-600 text-2xl font-bold">
                  {students.filter(s => {
                    const details = getStudentDetails(s);
                    return details.grade === 'A+' || details.grade === 'A';
                  }).length}
                </div>
                <div className="text-green-700 text-sm font-medium">A+ / A</div>
              </div>
              <div className="bg-yellow-50 rounded-lg p-4">
                <div className="text-yellow-600 text-2xl font-bold">
                  {Math.round(students.reduce((acc, s) => acc + getStudentDetails(s).percentage, 0) / students.length || 0)}%
                </div>
                <div className="text-yellow-700 text-sm font-medium">গড় স্কোর</div>
              </div>
              <div className="bg-purple-50 rounded-lg p-4">
                <div className="text-purple-600 text-2xl font-bold">
                  {Math.round((students.filter(s => {
                    const details = getStudentDetails(s);
                    return details.percentage >= 60;
                  }).length / students.length) * 100) || 0}%
                </div>
                <div className="text-purple-700 text-sm font-medium">পাসের হার</div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <input
                type="text"
                placeholder="নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="timestamp">সর্বশেষ</option>
                <option value="name">নাম অনুযায়ী</option>
                <option value="score">স্কোর অনুযায়ী</option>
              </select>
              <button
                onClick={onClearData}
                className="px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors"
              >
                সব ডেটা মুছুন
              </button>
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">নাম</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">মোবাইল</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">স্কোর</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">গ্রেড</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">সময়</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">তারিখ</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {students.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                        কোনো ছাত্রের ডেটা পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    students.map((student) => {
                      const details = getStudentDetails(student);
                      const date = new Date(student.timestamp);
                      
                      return (
                        <tr key={student.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {student.name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {student.mobile}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {details.correctAnswers}/{student.totalQuestions} ({details.percentage}%)
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              details.grade === 'A+' ? 'bg-green-100 text-green-800' : 
                              details.grade === 'A' ? 'bg-blue-100 text-blue-800' : 
                              details.grade === 'B' ? 'bg-yellow-100 text-yellow-800' : 
                              details.grade === 'C' ? 'bg-orange-100 text-orange-800' : 
                              'bg-red-100 text-red-800'
                            }`}>
                              {details.grade}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {Math.floor(student.timeTaken / 60)} মিনিট
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {date.toLocaleDateString('bn-BD')} {date.toLocaleTimeString('bn-BD')}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}