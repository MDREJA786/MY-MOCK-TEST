import React, { useState, useEffect } from 'react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface QuestionTranslations {
  [key: number]: {
    question: string;
    options: string[];
  };
}

interface ExamInterfaceProps {
  studentName: string;
  studentMobile: string;
  onSubmit: (answers: Record<number, number>, markedForReview: Set<number>, timeTaken: number) => void;
}

// Question Translations
const QUESTION_TRANSLATIONS: { [key: string]: QuestionTranslations } = {
  english: {
    1: { question: "When is Bangladesh Independence Day?", options: ["26 March", "16 December", "21 February", "14 December"] },
    2: { question: "What is the national fruit of Bangladesh?", options: ["Mango", "Jackfruit", "Flower", "Guava"] },
    3: { question: "What is the national bird of Bangladesh?", options: ["Doel", "Koel", "Myna", "Shama"] },
    4: { question: "When was the Constitution of Bangladesh enacted?", options: ["1971", "1972", "1973", "1974"] },
    5: { question: "Who was the first President of Bangladesh?", options: ["Sheikh Mujibur Rahman", "Syed Nazrul Islam", "Abu Sayeed Chowdhury", "Khondakar Moshtaq"] },
    6: { question: "Who composed the national anthem of Bangladesh?", options: ["Kazi Nazrul Islam", "Rabindranath Tagore", "Sukanta Bhattacharya", "Jibanananda Das"] },
    7: { question: "What is the currency of Bangladesh?", options: ["Rupee", "Taka", "Dollar", "Pound"] },
    8: { question: "What is the national flower of Bangladesh?", options: ["Rose", "Jasmine", "Shapla", "Champa"] },
    9: { question: "Which is the largest river in Bangladesh?", options: ["Padma", "Meghna", "Jamuna", "Brahmaputra"] },
    10: { question: "What is the national sport of Bangladesh?", options: ["Cricket", "Football", "Kabaddi", "Hockey"] },
    11: { question: "Who was the first Prime Minister of Bangladesh?", options: ["Tajuddin Ahmed", "Sheikh Hasina", "Khaleda Zia", "Hossain Shaheed Suhrawardy"] },
    12: { question: "What is the official language of Bangladesh?", options: ["English", "Bengali", "Urdu", "Arabic"] },
    13: { question: "What are the colors of the national flag of Bangladesh?", options: ["Green and Red", "Red and Green", "Yellow and Green", "Red and White"] },
    14: { question: "Which division is the largest in Bangladesh?", options: ["Dhaka", "Chittagong", "Rajshahi", "Khulna"] },
    15: { question: "What is the national emblem of Bangladesh?", options: ["Tree", "Water", "Flower", "All"] },
    16: { question: "What was the name of the first newspaper of Bangladesh?", options: ["Daily Bangla", "Daily Ittefaq", "Bangladesh Times", "The Bangladesh Observer"] },
    17: { question: "Where is the National Martyrs' Memorial located?", options: ["Dhaka", "Savar", "Gazipur", "Narayanganj"] },
    18: { question: "Which was the first university of Bangladesh?", options: ["Dhaka University", "Rajshahi University", "Chittagong University", "Jahangirnagar University"] },
    19: { question: "What is the national fish of Bangladesh?", options: ["Rui", "Katla", "Ilish", "Pangash"] },
    20: { question: "What is the name of the largest island of Bangladesh?", options: ["Bhola", "Maheshkhali", "St. Martin", "Sandwip"] },
    21: { question: "What is the scientific name of mango, the national fruit of Bangladesh?", options: ["Mangifera indica", "Mangifera sylvatica", "Mangifera odorata", "Mangifera zeylanica"] },
    22: { question: "Who was the first female Prime Minister of Bangladesh?", options: ["Sheikh Hasina", "Khaleda Zia", "Kazi Zafar Ahmed", "Abdul Malek"] },
    23: { question: "How many members are there in the Jatiya Sangsad of Bangladesh?", options: ["300", "350", "400", "450"] },
    24: { question: "What is the highest honor of Bangladesh?", options: ["Independence Award", "Ekushey Padak", "Bangladesh Award", "Swarna Padak"] },
    25: { question: "What is the national monument of Bangladesh?", options: ["Shapla", "Lotus", "Rose", "Jasmine"] },
    26: { question: "Who was the first female President of Bangladesh?", options: ["Sheikh Hasina", "Khaleda Zia", "Justice Shahabuddin", "No one yet"] },
    27: { question: "What is the first line of the national anthem of Bangladesh?", options: ["Amar Sonar Bangla", "Amar Sonar Bangla Ami Tomay Bhalobashi", "Mayer Dudher Moto Mitha", "Bangladesh Swadhin Hoyeche"] },
    28: { question: "Which is the largest forest area in Bangladesh?", options: ["Sundarbans", "Madhupur", "Sal Forest", "Gazipur"] },
    29: { question: "What is the national animal of Bangladesh?", options: ["Tiger", "Lion", "Elephant", "Royal Bengal Tiger"] },
    30: { question: "What was the duration of the Bangladesh Liberation War?", options: ["8 months", "9 months", "10 months", "11 months"] }
  },
  hindi: {
    1: { question: "बांग्लादेश का स्वतंत्रता दिवस कब है?", options: ["26 मार्च", "16 दिसंबर", "21 फरवरी", "14 दिसंबर"] },
    2: { question: "बांग्लादेश का राष्ट्रीय फल कौन सा है?", options: ["आम", "कटहल", "फूल", "अमरूद"] },
    3: { question: "बांग्लादेश का राष्ट्रीय पक्षी कौन सा है?", options: ["दोएल", "कोयल", "मैना", "श्यामा"] },
    4: { question: "बांग्लादेश का संविधान कब बनाया गया था?", options: ["1971", "1972", "1973", "1974"] },
    5: { question: "बांग्लादेश के पहले राष्ट्रपति कौन थे?", options: ["शेख मुजीबुर रहमान", "सैयद नजरूल इस्लाम", "अबू सईद चौधरी", "खोंदकार मोश्ताक"] },
    6: { question: "बांग्लादेश के राष्ट्रीय गान के रचयिता कौन हैं?", options: ["काजी नजरूल इस्लाम", "रवींद्रनाथ टैगोर", "सुकान्त भट्टाचार्य", "जीबनानंद दास"] },
    7: { question: "बांग्लादेश की मुद्रा क्या है?", options: ["रुपया", "टका", "डॉलर", "पाउंड"] },
    8: { question: "बांग्लादेश का राष्ट्रीय फूल कौन सा है?", options: ["गुलाब", "जास्मीन", "शपला", "चंपा"] },
    9: { question: "बांग्लादेश की सबसे बड़ी नदी कौन सी है?", options: ["पद्मा", "मेघना", "यमुना", "ब्रह्मपुत्र"] },
    10: { question: "बांग्लादेश का राष्ट्रीय खेल कौन सा है?", options: ["क्रिकेट", "फुटबॉल", "कबड्डी", "हॉकी"] },
    11: { question: "बांग्लादेश के पहले प्रधानमंत्री कौन थे?", options: ["ताजुद्दीन अहमद", "शेख हसीना", "खालिदा जिया", "हुसैन शहीद सोहरावर्दी"] },
    12: { question: "बांग्लादेश की आधिकारिक भाषा कौन सी है?", options: ["अंग्रेजी", "बांग्ला", "उर्दू", "अरबी"] },
    13: { question: "बांग्लादेश के राष्ट्रीय झंडे के रंग क्या हैं?", options: ["हरा और लाल", "लाल और हरा", "पीला और हरा", "लाल और सफेद"] },
    14: { question: "बांग्लादेश का कौन सा विभाग सबसे बड़ा है?", options: ["ढाका", "चिट्टागॉन्ग", "राजशाही", "खुलना"] },
    15: { question: "बांग्लादेश का राष्ट्रीय प्रतीक क्या है?", options: ["पेड़", "पानी", "फूल", "सभी"] },
    16: { question: "बांग्लादेश के पहले अखबार का नाम क्या था?", options: ["डेली बांग्ला", "डेली इत्तेफाक", "बांग्लादेश टाइम्स", "दि बांग्लादेश ऑब्जर्वर"] },
    17: { question: "बांग्लादेश का राष्ट्रीय शहीद स्मारक कहां स्थित है?", options: ["ढाका", "सावर", "गाजीपुर", "नारायणगंज"] },
    18: { question: "बांग्लादेश का पहला विश्वविद्यालय कौन सा था?", options: ["ढाका विश्वविद्यालय", "राजशाही विश्वविद्यालय", "चिट्टागॉन्ग विश्वविद्यालय", "जहांगीरनगर विश्वविद्यालय"] },
    19: { question: "बांग्लादेश की राष्ट्रीय मछली कौन सी है?", options: ["रुई", "कतला", "इलिश", "पंगाश"] },
    20: { question: "बांग्लादेश के सबसे बड़े द्वीप का नाम क्या है?", options: ["भोला", "महेशखाली", "सेंट मार्टिन", "संद्वीप"] },
    21: { question: "बांग्लादेश के राष्ट्रीय फल आम का वैज्ञानिक नाम क्या है?", options: ["Mangifera indica", "Mangifera sylvatica", "Mangifera odorata", "Mangifera zeylanica"] },
    22: { question: "बांग्लादेश की पहली महिला प्रधानमंत्री कौन थीं?", options: ["शेख हसीना", "खालिदा जिया", "काजी जफर अहमद", "अब्दुल मलिक"] },
    23: { question: "बांग्लादेश की जातीय संसद में कितने सदस्य हैं?", options: ["300", "350", "400", "450"] },
    24: { question: "बांग्लादेश का सर्वोच्च सम्मान क्या है?", options: ["स्वतंत्रता पुरस्कार", "एकुशे पदक", "बांग्लादेश पुरस्कार", "स्वर्ण पदक"] },
    25: { question: "बांग्लादेश का राष्ट्रीय स्मारक क्या है?", options: ["शपला", "कमल", "गुलाब", "जास्मीन"] },
    26: { question: "बांग्लादेश की पहली महिला राष्ट्रपति कौन थीं?", options: ["शेख हसीना", "खालिदा जिया", "न्यायाधीश शहाबुद्दीन", "अभी तक कोई नहीं"] },
    27: { question: "बांग्लादेश के राष्ट्रीय गान की पहली पंक्ति क्या है?", options: ["आमार सोनार बांग्ला", "आमार सोनार बांग्ला अमी तोमाय भालोबासी", "मायेर दुधेर मोतो मिठा", "बांग्लादेश स्वाधीन होयेचे"] },
    28: { question: "बांग्लादेश का सबसे बड़ा वन क्षेत्र कौन सा है?", options: ["सुंदरबन", "मधुपुर", "साल वन", "गाजीपुर"] },
    29: { question: "बांग्लादेश का राष्ट्रीय पशु कौन सा है?", options: ["बाघ", "शेर", "हाथी", "रॉयल बंगाल टाइगर"] },
    30: { question: "बांग्लादेश मुक्ति युद्ध की अवधि कितनी थी?", options: ["8 महीने", "9 महीने", "10 महीने", "11 महीने"] }
  }
};

const EXAM_QUESTIONS: Question[] = [
  { id: 1, question: "বাংলাদেশের স্বাধীনতা দিবস কবে?", options: ["২ মার্চ", "১৬ ডিসেম্বর", "২১ ফেব্রুয়ারি", "১ ডিসেম্বর"], correctAnswer: 0 },
  { id: 2, question: "বাংলাদেশের জাতীয় ফল কোনটি?", options: ["আম", "কাঁঠাল", "ফুল", "পেয়ারা"], correctAnswer: 1 },
  { id: 3, question: "বাংলাদেশের জাতীয় পাখির নাম কী?", options: ["দোয়েল", "কোয়েল", "ময়না", "শ্যামা"], correctAnswer: 0 },
  { id: 4, question: "বাংলাদেশের সংবিধান কবে প্রণয়ন করা হয়?", options: ["১৯১", "১৯৭২", "১৯৭৩", "১৯৭৪"], correctAnswer: 1 },
  { id: 5, question: "বাংলাদেশের প্রথম রাষ্ট্রপতি কে ছিলেন?", options: ["শেখ মুজিবুর রহমান", "সৈয়দ নজরুল ইসলাম", "আবু সাঈদ চৌধুরী", "খন্দকার মোশতাক"], correctAnswer: 0 },
  { id: 6, question: "বাংলাদেশের জাতীয় সঙ্গীতের রচয়িতা কে?", options: ["কাজী নজরুল ইসলাম", "রবীন্দ্রনাথ ঠাকুর", "সুকান্ত ভট্টাচার্য", "জীবনানন্দ দাশ"], correctAnswer: 1 },
  { id: 7, question: "বাংলাদেশের মুদ্রার নাম কী?", options: ["রুপি", "টাকা", "ডলার", "পাউন্ড"], correctAnswer: 1 },
  { id: 8, question: "বাংলাদেশের জাতীয় ফুল কোনটি?", options: ["গোলাপ", "জুঁই", "শাপলা", "চম্পা"], correctAnswer: 2 },
  { id: 9, question: "বাংলাদেশের কোনটি সবচেয়ে বড় নদী?", options: ["পদ্মা", "মেঘনা", "যমুনা", "ব্রহ্মপুত্র"], correctAnswer: 0 },
  { id: 10, question: "বাংলাদেশের জাতীয় ক্রীড়া কোনটি?", options: ["ক্রিকেট", "ফুটবল", "কাবাডি", "হকি"], correctAnswer: 2 },
  { id: 11, question: "বাংলাদেশের প্রথম প্রধানমন্ত্রী কে ছিলেন?", options: ["তাজউদ্দীন আহমদ", "শেখ হাসিনা", "খালেদা জিয়া", "হোসেন শহীদ সোহরাওয়ার্দী"], correctAnswer: 0 },
  { id: 12, question: "বাংলাদেশের সরকারি ভাষা কোনটি?", options: ["ইংরেজি", "বাংলা", "উর্দু", "আরবি"], correctAnswer: 1 },
  { id: 13, question: "বাংলাদেশের জাতীয় পতাকার রঙ কী কী?", options: ["সবুজ ও লাল", "লাল ও সবুজ", "হলুদ ও সবুজ", "লাল ও সাদা"], correctAnswer: 0 },
  { id: 14, question: "বাংলাদেশের কোন বিভাগ সবচেয়ে বড়?", options: ["ঢাকা", "চট্টগ্রাম", "রাজশাহী", "খুলনা"], correctAnswer: 1 },
  { id: 15, question: "বাংলাদেশের জাতীয় প্রতীক কী?", options: ["গাছ", "পানি", "ফুল", "সব"], correctAnswer: 2 },
  { id: 16, question: "বাংলাদেশের প্রথম সংবাদপত্রের নাম কী?", options: ["দৈনিক বাংলা", "দৈনিক ইত্তেফাক", "বাংলাদেশ টাইমস", "দি বাংলাদেশ অবজারভার"], correctAnswer: 1 },
  { id: 17, question: "বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায় অবস্থিত?", options: ["ঢাকা", "সাভার", "গাজীপুর", "নারায়ণগঞ্জ"], correctAnswer: 1 },
  { id: 18, question: "বাংলাদেশের প্রথম বিশ্ববিদ্যালয় কোনটি?", options: ["ঢাকা বিশ্ববিদ্যালয়", "রাজশাহী বিশ্ববিদ্যালয়", "চট্টগ্রাম বিশ্ববিদ্যালয়", "জাহাঙ্গীরনগর বিশ্ববিদ্যালয়"], correctAnswer: 0 },
  { id: 19, question: "বাংলাদেশের জাতীয় মাছ কোনটি?", options: ["রুই", "কাতল", "ইলিশ", "পাঙ্গাশ"], correctAnswer: 2 },
  { id: 20, question: "বাংলাদেশের সবচেয়ে বড় দ্বীপের নাম কী?", options: ["ভোলা", "মহেশখালী", "সেন্ট মার্টিন", "সন্দ্বীপ"], correctAnswer: 0 },
  { id: 21, question: "বাংলাদেশের জাতীয় ফল আমের বৈজ্ঞানিক নাম কী?", options: ["Mangifera indica", "Mangifera sylvatica", "Mangifera odorata", "Mangifera zeylanica"], correctAnswer: 0 },
  { id: 22, question: "বাংলাদেশের প্রথম মহিলা প্রধানমন্ত্রী কে?", options: ["শেখ হাসিনা", "খালেদা জিয়া", "কাজী জাফর আহমেদ", "আব্দুল মালেক"], correctAnswer: 1 },
  { id: 23, question: "বাংলাদেশের জাতীয় সংসদের সদস্য সংখ্যা কত?", options: ["৩০", "৩৫০", "৪০০", "৪৫০"], correctAnswer: 0 },
  { id: 24, question: "বাংলাদেশের সর্বোচ্চ সম্মাননা কোনটি?", options: ["স্বাধীনতা পদক", "একুশে পদক", "বাংলাদেশ পদক", "স্বর্ণ পদক"], correctAnswer: 0 },
  { id: 25, question: "বাংলাদেশের জাতীয় স্মারক কোনটি?", options: ["শাপলা", "পদ্মফুল", "গোলাপ", "জুঁই"], correctAnswer: 0 },
  { id: 26, question: "বাংলাদেশের প্রথম মহিলা রাষ্ট্রপতি কে?", options: ["শেখ হাসিনা", "খালেদা জিয়া", "বিচারপতি সাহাবুদ্দিন", "এখনও কেউ হয়নি"], correctAnswer: 3 },
  { id: 27, question: "বাংলাদেশের জাতীয় সঙ্গীতের প্রথম লাইন কী?", options: ["আমার সোনার বাংলা", "আমার সোনার বাংলা আমি তোমায় ভালোবাসি", "মায়ের দুধের মতো মিঠা", "বাংলাদেশ স্বাধীন হয়েছে"], correctAnswer: 1 },
  { id: 28, question: "বাংলাদেশের সবচেয়ে বড় বনাঞ্চল কোনটি?", options: ["সুন্দরবন", "মাদারপুর", "শালবন", "গাজীপুর"], correctAnswer: 0 },
  { id: 29, question: "বাংলাদেশের জাতীয় পশু কোনটি?", options: ["বাঘ", "সিংহ", "হাতি", "রয়্যাল বেঙ্গল টাইগার"], correctAnswer: 3 },
  { id: 30, question: "বাংলাদেশের স্বাধীনতা যুদ্ধের সময়কাল কতদিন?", options: ["৮ মাস", "৯ মাস", "১০ মাস", "১১ মাস"], correctAnswer: 1 }
];

export function ExamInterface({ studentName, studentMobile, onSubmit }: ExamInterfaceProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [markedForReview, setMarkedForReview] = useState<Set<number>>(new Set());
  const [visitedQuestions, setVisitedQuestions] = useState<Set<number>>(new Set([0]));
  const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes in seconds
  const [selectedLanguage, setSelectedLanguage] = useState('bengali');
  const [isFullScreen, setIsFullScreen] = useState(false);

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (optionIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [EXAM_QUESTIONS[currentQuestion].id]: optionIndex
    }));
  };

  const handleSaveAndNext = () => {
    if (currentQuestion < EXAM_QUESTIONS.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setVisitedQuestions(prev => new Set([...prev, currentQuestion + 1]));
    }
  };

  const handleMarkForReviewAndNext = () => {
    setMarkedForReview(prev => new Set([...prev, EXAM_QUESTIONS[currentQuestion].id]));
    if (currentQuestion < EXAM_QUESTIONS.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setVisitedQuestions(prev => new Set([...prev, currentQuestion + 1]));
    }
  };

  const handleClearResponse = () => {
    setAnswers(prev => {
      const newAnswers = { ...prev };
      delete newAnswers[EXAM_QUESTIONS[currentQuestion].id];
      return newAnswers;
    });
  };

  const handleSubmit = () => {
    if (confirm('Do you want to submit the exam?')) {
      onSubmit(answers, markedForReview, 30 * 60 - timeLeft);
    }
  };

  const handleQuestionJump = (index: number) => {
    setCurrentQuestion(index);
    setVisitedQuestions(prev => new Set([...prev, index]));
  };

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullScreen(true);
    } else {
      document.exitFullscreen();
      setIsFullScreen(false);
    }
  };

  const getQuestionStatus = (index: number) => {
    const questionId = EXAM_QUESTIONS[index].id;
    const isAnswered = answers[questionId] !== undefined;
    const isMarked = markedForReview.has(questionId);
    const isVisited = visitedQuestions.has(index);
    const isCurrent = index === currentQuestion;

    if (isCurrent) return 'current';
    if (!isVisited) return 'not-visited';
    if (isAnswered && isMarked) return 'answered-marked';
    if (isMarked) return 'marked';
    if (isAnswered) return 'answered';
    return 'not-answered';
  };

  const getTranslatedQuestion = (questionId: number) => {
    if (selectedLanguage === 'bengali') {
      return EXAM_QUESTIONS.find(q => q.id === questionId)!;
    }
    const translation = QUESTION_TRANSLATIONS[selectedLanguage][questionId];
    return {
      id: questionId,
      question: translation.question,
      options: translation.options,
      correctAnswer: EXAM_QUESTIONS.find(q => q.id === questionId)!.correctAnswer
    };
  };

  const currentQ = getTranslatedQuestion(EXAM_QUESTIONS[currentQuestion].id);
  const answeredCount = Object.keys(answers).length;
  const markedCount = markedForReview.size;
  const notVisitedCount = EXAM_QUESTIONS.length - visitedQuestions.size;
  const notAnsweredCount = visitedQuestions.size - answeredCount;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Top Header Bar */}
      <div className="bg-white shadow-md border-b-2 border-blue-600">
        <div className="max-w-[1920px] mx-auto px-4 py-3">
          <div className="flex items-center justify-between flex-wrap gap-3">
            {/* Logo and Title */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">MT</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">Mock Test Platform</h1>
                  <p className="text-xs text-gray-600">Economic Survey 2025-26 Highlights: Special Test</p>
                </div>
              </div>
            </div>

            {/* Timer */}
            <div className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 rounded-lg shadow-lg">
              <span className="font-bold">Time Left</span>
              <div className="flex gap-1">
                {formatTime(timeLeft).split(':').map((part, i) => (
                  <React.Fragment key={i}>
                    <div className="bg-white/20 px-2 py-1 rounded font-mono font-bold min-w-[30px] text-center">
                      {part}
                    </div>
                    {i < 2 && <span className="font-bold">:</span>}
                  </React.Fragment>
                ))}
              </div>
            </div>

            {/* Full Screen and Language */}
            <div className="flex items-center gap-3">
              <button
                onClick={toggleFullScreen}
                className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-all font-medium border border-blue-200"
              >
                {isFullScreen ? 'Exit Full Screen' : 'Enter Full Screen'}
              </button>
              
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="px-4 py-2 border-2 border-blue-200 rounded-lg focus:outline-none focus:border-blue-500 bg-white font-medium"
              >
                <option value="bengali">বাংলা</option>
                <option value="english">English</option>
                <option value="hindi">हिन्दी</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-80px)]">
        {/* Question Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Question Info Bar */}
          <div className="bg-white border-b border-gray-200 px-6 py-3">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-4">
                <span className="bg-blue-100 text-blue-700 px-4 py-1.5 rounded-full font-semibold text-sm">
                  Question {currentQuestion + 1} / {EXAM_QUESTIONS.length}
                </span>
                <span className="text-gray-600 text-sm">
                  {answeredCount} টি উত্তর দেওয়া হয়েছে
                </span>
              </div>
              
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-xs text-gray-600">Marks</div>
                    <div className="flex gap-2">
                      <span className="bg-green-500 text-white px-2 py-0.5 rounded text-xs font-bold">+1</span>
                      <span className="bg-red-500 text-white px-2 py-0.5 rounded text-xs font-bold">-0</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-gray-600">Time</div>
                    <div className="text-sm font-semibold">{formatTime(30 * 60 - timeLeft)}</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">View in</span>
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    className="px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:outline-none focus:border-blue-500"
                  >
                    <option value="bengali">বাংলা</option>
                    <option value="english">English</option>
                    <option value="hindi">हिन्दी</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Question Content */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-5xl mx-auto">
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-8 leading-relaxed">
                  {currentQ.question}
                </h2>

                <div className="space-y-4">
                  {currentQ.options.map((option, index) => (
                    <label
                      key={index}
                      className={`flex items-center gap-4 p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 hover:shadow-md ${
                        answers[EXAM_QUESTIONS[currentQuestion].id] === index
                          ? 'border-blue-500 bg-blue-50 shadow-md'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="relative">
                        <input
                          type="radio"
                          name={`question-${EXAM_QUESTIONS[currentQuestion].id}`}
                          checked={answers[EXAM_QUESTIONS[currentQuestion].id] === index}
                          onChange={() => handleAnswerSelect(index)}
                          className="sr-only"
                        />
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                          answers[EXAM_QUESTIONS[currentQuestion].id] === index
                            ? 'border-blue-500 bg-blue-500'
                            : 'border-gray-400'
                        }`}>
                          {answers[EXAM_QUESTIONS[currentQuestion].id] === index && (
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                          )}
                        </div>
                      </div>
                      <span className={`text-lg flex-1 ${
                        answers[EXAM_QUESTIONS[currentQuestion].id] === index
                          ? 'text-blue-700 font-medium'
                          : 'text-gray-700'
                      }`}>
                        {option}
                      </span>
                      <span className="text-sm font-semibold text-gray-500">
                        {String.fromCharCode(65 + index)}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Action Bar */}
          <div className="bg-white border-t-2 border-gray-200 px-6 py-4">
            <div className="max-w-5xl mx-auto flex items-center justify-between flex-wrap gap-4">
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    if (currentQuestion > 0) {
                      setCurrentQuestion(prev => prev - 1);
                    }
                  }}
                  disabled={currentQuestion === 0}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium border border-gray-300 min-w-[140px]"
                >
                  ← Previous
                </button>
                
                <button
                  onClick={handleClearResponse}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-all font-medium border border-gray-300 min-w-[140px]"
                >
                  Clear Response
                </button>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleMarkForReviewAndNext}
                  className="px-6 py-3 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-all font-medium border border-purple-300 min-w-[180px]"
                >
                  Mark for Review & Next
                </button>
                
                <button
                  onClick={handleSaveAndNext}
                  className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all font-semibold shadow-lg hover:shadow-xl min-w-[140px]"
                >
                  Save & Next
                </button>
              </div>

              <button
                onClick={handleSubmit}
                className="px-8 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold shadow-lg hover:shadow-xl"
              >
                Submit Test
              </button>
            </div>
          </div>
        </div>

        {/* Right Sidebar - Question Palette */}
        <div className="w-80 bg-white border-l-2 border-gray-200 flex flex-col overflow-hidden">
          {/* Student Info */}
          <div className="p-4 border-b-2 border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                {studentName.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="font-bold text-gray-800">{studentName}</div>
                <div className="text-xs text-gray-600">{studentMobile}</div>
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="p-4 border-b-2 border-gray-200 bg-gray-50">
            <h3 className="font-bold text-gray-800 mb-3 text-sm">STATUS LEGEND</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-white border-2 border-gray-300"></div>
                <span className="text-gray-700">Not Visited</span>
                <span className="ml-auto font-bold text-gray-900">{notVisitedCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-red-500"></div>
                <span className="text-gray-700">Not Answered</span>
                <span className="ml-auto font-bold text-gray-900">{notAnsweredCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-green-500"></div>
                <span className="text-gray-700">Answered</span>
                <span className="ml-auto font-bold text-gray-900">{answeredCount - markedCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-purple-500"></div>
                <span className="text-gray-700">Marked</span>
                <span className="ml-auto font-bold text-gray-900">{markedCount}</span>
              </div>
              <div className="flex items-center gap-2 col-span-2">
                <div className="w-5 h-5 rounded bg-gradient-to-r from-green-500 to-purple-500"></div>
                <span className="text-gray-700">Answered & Marked</span>
              </div>
            </div>
          </div>

          {/* Question Grid */}
          <div className="flex-1 overflow-y-auto p-4">
            <h3 className="font-bold text-gray-800 mb-3 text-sm">SECTION: Test</h3>
            <div className="grid grid-cols-5 gap-2">
              {EXAM_QUESTIONS.map((_, index) => {
                const status = getQuestionStatus(index);
                return (
                  <button
                    key={index}
                    onClick={() => handleQuestionJump(index)}
                    className={`w-10 h-10 rounded-lg font-semibold text-sm transition-all border-2 ${
                      status === 'current'
                        ? 'bg-gray-800 text-white border-gray-800 scale-110 shadow-lg'
                        : status === 'answered'
                        ? 'bg-green-500 text-white border-green-600 hover:shadow-md'
                        : status === 'marked'
                        ? 'bg-purple-500 text-white border-purple-600 hover:shadow-md'
                        : status === 'answered-marked'
                        ? 'bg-gradient-to-r from-green-500 to-purple-500 text-white border-purple-600 hover:shadow-md'
                        : status === 'not-answered'
                        ? 'bg-red-500 text-white border-red-600 hover:shadow-md'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400 hover:shadow-md'
                    }`}
                  >
                    {index + 1}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Bottom Buttons */}
          <div className="p-4 border-t-2 border-gray-200 bg-gray-50 space-y-3">
            <button className="w-full px-4 py-3 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-all font-medium border border-blue-300">
              Question Paper
            </button>
            
            <button className="w-full px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-all font-medium border border-gray-300">
              Instructions
            </button>
            
            <button
              onClick={handleSubmit}
              className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all font-semibold shadow-lg"
            >
              Submit Test
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
