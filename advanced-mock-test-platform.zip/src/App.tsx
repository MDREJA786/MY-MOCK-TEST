import { useState } from 'react';
import { StudentLogin } from './components/StudentLogin';
import { Instructions } from './components/Instructions';
import { ExamInterface } from './components/ExamInterface';
import { Results } from './components/Results';
import { AdminPanel } from './components/AdminPanel';

interface StudentData {
  id: string;
  name: string;
  mobile: string;
  answers: Record<number, number>;
  markedForReview: Set<number>;
  timeTaken: number;
  timestamp: Date;
  score: number;
  totalQuestions: number;
}

const examQuestions = [
  { id: 1, question: "বাংলাদেশের স্বাধীনতা দিবস কবে?", options: ["২৬ মার্চ", "১৬ ডিসেম্বর", "২১ ফেব্রুয়ারি", "১৪ ডিসেম্বর"], correctAnswer: 0 },
  { id: 2, question: "বাংলাদেশের জাতীয় ফল কোনটি?", options: ["আম", "কাঁঠাল", "ফুল", "পেয়ারা"], correctAnswer: 1 },
  { id: 3, question: "বাংলাদেশের জাতীয় পাখির নাম কী?", options: ["দোয়েল", "কোয়েল", "ময়না", "শ্যামা"], correctAnswer: 0 },
  { id: 4, question: "বাংলাদেশের সংবিধান কবে প্রণয়ন করা হয়?", options: ["১৯৭১", "১৯৭২", "১৯৭৩", "১৯৭৪"], correctAnswer: 1 },
  { id: 5, question: "বাংলাদেশের প্রথম রাষ্ট্রপতি কে ছিলেন?", options: ["শেখ মুজিবুর রহমান", "সৈয়দ নজরুল ইসলাম", "আবু সাঈদ চৌধুরী", "খন্দকার মোশতাক"], correctAnswer: 0 },
  { id: 6, question: "বাংলাদেশের জাতীয় সঙ্গীতের রচয়িতা কে?", options: ["কাজী নজরুল ইসলাম", "রবীন্দ্রনাথ ঠাকুর", "সুকান্ত ভট্টাচার্য", "জীবনানন্দ দাশ"], correctAnswer: 1 },
  { id: 7, question: "বাংলাদেশের মুদ্রার নাম কী?", options: ["রুপি", "টাকা", "ডলার", "পাউন্ড"], correctAnswer: 1 },
  { id: 8, question: "বাংলাদেশের জাতীয় ফুল কোনটি?", options: ["গোলাপ", "জুঁই", "শাপলা", "চম্পা"], correctAnswer: 2 },
  { id: 9, question: "বাংলাদেশের কোনটি সবচেয়ে বড় নদী?", options: ["পদ্মা", "মেঘনা", "যমুনা", "ব্রহ্মপুত্র"], correctAnswer: 0 },
  { id: 10, question: "বাংলাদেশের জাতীয় ক্রীড়া কোনটি?", options: ["ক্রিকেট", "ফুটবল", "কাবাডি", "হকি"], correctAnswer: 2 },
  { id: 11, question: "বাংলাদেশের প্রথম প্রধানমন্ত্রী কে ছিলেন?", options: ["তাজউদ্দীন আহমদ", "শেখ হাসিনা", "খালেদা জিয়া", "হোসেন শহীদ সোহরাওয়ার্দী"], correctAnswer: 0 },
  { id: 12, question: "বাংলাদেশের সরকারি ভাষা কোনটি?", options: ["ইংরেজি", "বাংলা", "উর্দু", "আরবি"], correctAnswer: 1 },
  { id: 13, question: "বাংলাদেশের জাতীয় পতাকার রঙ কী কী?", options: ["সবুজ ও লাল", "লাল ও সবুজ", "হলুদ ও সবুজ", "লাল ও সাদা"], correctAnswer: 0 },
  { id: 14, question: "বাংলাদেশের কোন বিভাগ সবচেয়ে বড়?", options: ["ঢাকা", "চট্টগ্রাম", "রাজশাহী", "খুলনা"], correctAnswer: 1 },
  { id: 15, question: "বাংলাদেশের জাতীয় প্রতীক কী?", options: ["গাছ", "পানি", "ফুল", "সব"], correctAnswer: 2 },
  { id: 16, question: "বাংলাদেশের প্রথম সংবাদপত্রের নাম কী?", options: ["দৈনিক বাংলা", "দৈনিক ইত্তেফাক", "বাংলাদেশ টাইমস", "দি বাংলাদেশ অবজারভার"], correctAnswer: 1 },
  { id: 17, question: "বাংলাদেশের জাতীয় স্মৃতিসৌধ কোথায় অবস্থিত?", options: ["ঢাকা", "সাভার", "গাজীপুর", "নারায়ণগঞ্জ"], correctAnswer: 1 },
  { id: 18, question: "বাংলাদেশের প্রথম বিশ্ববিদ্যালয় কোনটি?", options: ["ঢাকা বিশ্ববিদ্যালয়", "রাজশাহী বিশ্ববিদ্যালয়", "চট্টগ্রাম বিশ্ববিদ্যালয়", "জাহাঙ্গীরনগর বিশ্ববিদ্যালয়"], correctAnswer: 0 },
  { id: 19, question: "বাংলাদেশের জাতীয় মাছ কোনটি?", options: ["রুই", "কাতল", "ইলিশ", "পাঙ্গাশ"], correctAnswer: 2 },
  { id: 20, question: "বাংলাদেশের সবচেয়ে বড় দ্বীপের নাম কী?", options: ["ভোলা", "মহেশখালী", "সেন্ট মার্টিন", "সন্দ্বীপ"], correctAnswer: 0 },
  { id: 21, question: "বাংলাদেশের জাতীয় ফল আমের বৈজ্ঞানিক নাম কী?", options: ["Mangifera indica", "Mangifera sylvatica", "Mangifera odorata", "Mangifera zeylanica"], correctAnswer: 0 },
  { id: 22, question: "বাংলাদেশের প্রথম মহিলা প্রধানমন্ত্রী কে?", options: ["শেখ হাসিনা", "খালেদা জিয়া", "কাজী জাফর আহমেদ", "আব্দুল মালেক"], correctAnswer: 1 },
  { id: 23, question: "বাংলাদেশের জাতীয় সংসদের সদস্য সংখ্যা কত?", options: ["৩০০", "৩৫০", "৪০০", "৪৫০"], correctAnswer: 0 },
  { id: 24, question: "বাংলাদেশের সর্বোচ্চ সম্মাননা কোনটি?", options: ["স্বাধীনতা পদক", "একুশে পদক", "বাংলাদেশ পদক", "স্বর্ণ পদক"], correctAnswer: 0 },
  { id: 25, question: "বাংলাদেশের জাতীয় স্মারক কোনটি?", options: ["শাপলা", "পদ্মফুল", "গোলাপ", "জুঁই"], correctAnswer: 0 },
  { id: 26, question: "বাংলাদেশের প্রথম মহিলা রাষ্ট্রপতি কে?", options: ["শেখ হাসিনা", "খালেদা জিয়া", "বিচারপতি সাহাবুদ্দিন", "এখনও কেউ হয়নি"], correctAnswer: 3 },
  { id: 27, question: "বাংলাদেশের জাতীয় সঙ্গীতের প্রথম লাইন কী?", options: ["আমার সোনার বাংলা", "আমার সোনার বাংলা আমি তোমায় ভালোবাসি", "মায়ের দুধের মতো মিঠা", "বাংলাদেশ স্বাধীন হয়েছে"], correctAnswer: 1 },
  { id: 28, question: "বাংলাদেশের সবচেয়ে বড় বনাঞ্চল কোনটি?", options: ["সুন্দরবন", "মাদারপুর", "শালবন", "গাজীপুর"], correctAnswer: 0 },
  { id: 29, question: "বাংলাদেশের জাতীয় পশু কোনটি?", options: ["বাঘ", "সিংহ", "হাতি", "রয়্যাল বেঙ্গল টাইগার"], correctAnswer: 3 },
  { id: 30, question: "বাংলাদেশের স্বাধীনতা যুদ্ধের সময়কাল কতদিন?", options: ["৮ মাস", "৯ মাস", "১০ মাস", "১১ মাস"], correctAnswer: 1 }
];

type AppScreen = 'login' | 'instructions' | 'exam' | 'results' | 'admin';

export function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('login');
  const [studentName, setStudentName] = useState('');
  const [studentMobile, setStudentMobile] = useState('');
  const [studentAnswers, setStudentAnswers] = useState<Record<number, number>>({});
  const [markedForReview, setMarkedForReview] = useState<Set<number>>(new Set());
  const [timeTaken, setTimeTaken] = useState(0);
  const [students, setStudents] = useState<StudentData[]>([]);
  
  // Check for admin access
  const isAdmin = window.location.hash === '#admin';
  
  useState(() => {
    if (isAdmin) {
      setCurrentScreen('admin');
    }
  });

  const handleLogin = (name: string, mobile: string) => {
    setStudentName(name);
    setStudentMobile(mobile);
    setCurrentScreen('instructions');
  };

  const handleStartExam = () => {
    setCurrentScreen('exam');
  };

  const handleExamSubmit = (answers: Record<number, number>, marked: Set<number>, timeSpent: number) => {
    setStudentAnswers(answers);
    setMarkedForReview(marked);
    setTimeTaken(timeSpent);
    
    // Calculate score
    let correctAnswers = 0;
    examQuestions.forEach(q => {
      if (answers[q.id] === q.correctAnswer) {
        correctAnswers++;
      }
    });
    
    // Save student data
    const studentData: StudentData = {
      id: `${Date.now()}-${Math.random()}`,
      name: studentName,
      mobile: studentMobile,
      answers,
      markedForReview: marked,
      timeTaken: timeSpent,
      timestamp: new Date(),
      score: correctAnswers,
      totalQuestions: examQuestions.length
    };
    
    // In a real app, this would be saved to a backend
    // For now, we'll store it in state and localStorage
    const existingStudents = JSON.parse(localStorage.getItem('students') || '[]');
    const updatedStudents = [...existingStudents, {
      ...studentData,
      timestamp: studentData.timestamp.toISOString(),
      markedForReview: Array.from(marked)
    }];
    localStorage.setItem('students', JSON.stringify(updatedStudents));
    
    setStudents(updatedStudents.map(s => ({
      ...s,
      timestamp: new Date(s.timestamp),
      markedForReview: new Set(s.markedForReview)
    })));
    
    setCurrentScreen('results');
  };

  const handleRestart = () => {
    setCurrentScreen('login');
    setStudentName('');
    setStudentMobile('');
    setStudentAnswers({});
    setMarkedForReview(new Set());
    setTimeTaken(0);
  };

  const handleClearData = () => {
    if (confirm('Are you sure you want to delete all student data?')) {
      localStorage.removeItem('students');
      setStudents([]);
    }
  };

  // Load students data for admin
  if (currentScreen === 'admin' && students.length === 0) {
    const savedStudents = JSON.parse(localStorage.getItem('students') || '[]');
    setStudents(savedStudents.map((s: any) => ({
      ...s,
      timestamp: new Date(s.timestamp),
      markedForReview: new Set(s.markedForReview)
    })));
  }

  return (
    <>
      {currentScreen === 'login' && <StudentLogin onLogin={handleLogin} />}
      {currentScreen === 'instructions' && <Instructions studentName={studentName} onStartExam={handleStartExam} />}
      {currentScreen === 'exam' && (
        <ExamInterface 
          studentName={studentName}
          studentMobile={studentMobile}
          onSubmit={handleExamSubmit}
        />
      )}
      {currentScreen === 'results' && (
        <Results
          studentName={studentName}
          studentMobile={studentMobile}
          answers={studentAnswers}
          markedForReview={markedForReview}
          timeTaken={timeTaken}
          questions={examQuestions}
          onRestart={handleRestart}
        />
      )}
      {currentScreen === 'admin' && (
        <AdminPanel
          students={students}
          onClearData={handleClearData}
        />
      )}
    </>
  );
}